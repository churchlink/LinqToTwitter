namespace LinqToTwitter
{
    enum FavoritesAction
    {
        SingleStatus
    }
}