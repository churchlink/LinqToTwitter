namespace LinqToTwitter
{
    enum FriendshipAction
    {
        Create,
        Destroy,
        Update
    }
}