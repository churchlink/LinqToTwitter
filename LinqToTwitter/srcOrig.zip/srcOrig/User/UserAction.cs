namespace LinqToTwitter
{
    enum UserAction
    {
        SingleUser
    }
}