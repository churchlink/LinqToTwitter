﻿using System;
using System.Linq;

namespace LinqToTwitter
{
    public enum VineType
    {
        /// <summary>
        /// Get embedded vine video info.
        /// </summary>
        Oembed,
    }
}
