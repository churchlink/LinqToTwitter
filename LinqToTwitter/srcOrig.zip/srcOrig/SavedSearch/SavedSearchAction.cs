namespace LinqToTwitter
{
    enum SavedSearchAction
    {
        Create,

        Destroy
    }
}