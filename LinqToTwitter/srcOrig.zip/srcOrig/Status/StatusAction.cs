namespace LinqToTwitter
{
    enum StatusAction
    {
        SingleStatus,

        MediaUpload
    }
}