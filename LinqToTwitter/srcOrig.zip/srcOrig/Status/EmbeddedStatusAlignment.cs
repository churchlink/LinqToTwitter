﻿using System;

namespace LinqToTwitter
{
    public enum EmbeddedStatusAlignment
    {
        None,

        Left,

        Right,

        Center
    }
}
