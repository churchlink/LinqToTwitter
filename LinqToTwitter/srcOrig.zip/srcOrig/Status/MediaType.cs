﻿using System;
using System.Linq;

namespace LinqToTwitter
{
    public enum MediaType
    {
        Image
    }
}
