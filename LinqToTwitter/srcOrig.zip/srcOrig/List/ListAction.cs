namespace LinqToTwitter
{
    enum ListAction
    {
        Create,

        Update,

        Delete,

        AddMember,

        AddMemberRange,

        DeleteMember,

        Subscribe,

        Unsubscribe, 

        DestroyAll
    }
}