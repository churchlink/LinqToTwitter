﻿namespace LinqToTwitter
{
    /// <summary>
    /// type of search
    /// </summary>
    public enum SearchType
    {
        /// <summary>
        /// implemented mostly for consistency
        /// with the rest of the API
        /// </summary>
        Search
    }
}
