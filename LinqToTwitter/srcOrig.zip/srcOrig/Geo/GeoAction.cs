﻿using System;

namespace LinqToTwitter
{
    enum GeoAction
    {
        CreatePlace
    }
}
